#ifndef _VIDEO_H
#define _VIDEO_H

void rgbToHsv( unsigned char r, unsigned char  g, unsigned char b, unsigned int *h, unsigned char *s, unsigned char *v );

//---------------------------------------------------------------------------
#endif
