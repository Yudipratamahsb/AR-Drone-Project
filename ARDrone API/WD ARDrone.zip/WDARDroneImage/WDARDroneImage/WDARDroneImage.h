// D�sactive le warning C4200: extension non standard utilis�e�: tableau de taille z�ro dans un struct/union
__pragma(warning(disable:4200));

// D�sactive le warning C4154: suppression d'une expression de tableau�; conversion en pointeur fournie
__pragma(warning(disable:4154));

// Raccourcis
typedef unsigned short ushort;
typedef unsigned char byte;
typedef unsigned int uint;
#define WDEXPORT __declspec(dllexport) __cdecl
#define Vrai true
#define Faux false

// Donn�es d'un macrobloc
typedef struct _MacroblocData {
	int Data[64];
} MacroblocData;

// Description d'un macrobloc
typedef struct _Macrobloc {
	MacroblocData DataBlocs[6];
} Macrobloc;

// Description d'une tranche
typedef struct _Tranche {
	Macrobloc* Macroblocs;
	uint Occurrence;
} Tranche;

// Description du retour de ImageDecode
typedef struct _ImageDecodee {
	int		nFormat;
	uint	nLargeur;
	uint	nHauteur;
	uint	nDataSize;
	ushort*	nData;	
} ImageDecodee;

#ifdef __cplusplus
extern "C" {
#endif

// R�sum� : D�code un flux de donn�es et retourne les pixels correspondant
// Syntaxe :
//ImageDecode (<tabFlux> est tableau, <nTailleFlux> est entier, <stImageDecodee> est ImageDecodee)
//
// Param�tres :
//	tabFlux (tableau d'octets) : Flux de donn�es � d�coder
//  nTailleFlux (entier) : Taille (en octets) du flux de donn�es
//  stImageDecodee (ImageDecodee) (Sortie) : Informations et donn�es de l'image d�cod�e
// Valeur de retour :
// 	bool�en : Vrai si l'image a �t� correctement d�cod�e, Faux sinon
//
BOOL WDEXPORT ImageDecode(const byte * tabFlux, uint nTailleFlux, ImageDecodee * stImageDecodee);

// R�sum� : Lib�re la m�moire allou�e pour l'image d�cod�e
// Syntaxe :
//ImageDecodeLibere (<nData> est entier syst�me)
//
// Param�tres :
//	nData (entier syst�me) : R�f�rence sur le pointeur des donn�es de l'image d�cod�e
// Valeur de retour :
// 	bool�en : Vrai si la lib�ration a �t� correctement effectu�e, Faux sinon
//
BOOL WDEXPORT ImageDecodeLibere(ushort * nData);

#ifdef __cplusplus
}
#endif

uint	FluxDonneesLit(int nTotal);
void	EnteteLit();
BOOL	FluxTraite(int pnTailleFlux, ImageDecodee * stImageDecodee);
void	BlocOctetsRecupere(BOOL bAcCoefficientsDisponible);
BOOL	TransformationInverse(int nIndexMacrobloc, int nIndexDatabloc);
void	TrancheCompose();
void	DecodeOctets(int * nExec, int * nNiveau, BOOL * bDernier);
uint	FluxDonneesPeek(byte * tabFlux, int nTotal);
void	FluxDonneesAligne();
int		Sature5(int x);
int		Sature6(int x);
int		CLZ(uint nValeur);