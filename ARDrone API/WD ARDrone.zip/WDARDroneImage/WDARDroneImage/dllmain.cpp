// dllmain.cpp : D�finit le point d'entr�e pour l'application DLL.
#include "stdafx.h"

// Point d'entr�e de la DLL
BOOL APIENTRY DllMain(HMODULE hModule,
                       DWORD  dwReason,
                       LPVOID lpReserved
					 )
{
	switch (dwReason)
	{
	case DLL_PROCESS_ATTACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}

