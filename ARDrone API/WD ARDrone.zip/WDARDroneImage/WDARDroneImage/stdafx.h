#pragma once

#define WIN32_LEAN_AND_MEAN             // Exclure les en-t�tes Windows rarement utilis�s

// Fichiers d'en-t�te Windows�:
#include <windows.h>

