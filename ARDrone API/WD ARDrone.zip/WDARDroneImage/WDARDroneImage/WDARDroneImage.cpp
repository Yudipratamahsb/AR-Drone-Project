// WDARDroneImage.cpp�: d�finit les fonctions export�es pour l'application DLL.
//

#include "stdafx.h"

// Fichiers d'en-t�te du projet
#include "WDARDroneImage.h"

// Constantes
const int CONST_BlockWidth 			= 8;
const int CONST_BlockSize 			= 64;
const int CONST_WidthCif 			= 88;
const int CONST_HeightCif 			= 72;
const int CONST_WidthVga 			= 160;
const int CONST_HeightVga 			= 120;
const int CONST_TableQuantization	= 31;
const int FIX_0_298631336 			= 2446;
const int FIX_0_390180644 			= 3196;
const int FIX_0_541196100 			= 4433;
const int FIX_0_765366865 			= 6270;
const int FIX_0_899976223 			= 7373;
const int FIX_1_175875602 			= 9633;
const int FIX_1_501321110 			= 12299;
const int FIX_1_847759065 			= 15137;
const int FIX_1_961570560 			= 16069;
const int FIX_2_053119869 			= 16819;
const int FIX_2_562915447 			= 20995;
const int FIX_3_072711026 			= 25172;
const int CONST_BITS 				= 13;
const int PASS1_BITS 				= 1;
const int F1 						= (CONST_BITS - PASS1_BITS - 1);
const int F2 						= (CONST_BITS - PASS1_BITS);
const int F3 						= (CONST_BITS + PASS1_BITS + 3);

// Variables globales
short		m_tabQuantificateur[64] = {		 3,  5,  7,  9, 11, 13, 15, 17,
											 5,  7,  9, 11, 13, 15, 17, 19,
											 7,  9, 11, 13, 15, 17, 19, 21,
											 9, 11, 13, 15, 17, 19, 21, 23,
											11, 13, 15, 17, 19, 21, 23, 25,
											13, 15, 17, 19, 21, 23, 25, 27,
											15, 17, 19, 21, 23, 25, 27, 29,
											17, 19, 21, 23, 25, 27, 29, 31
									  };
short		m_tabZigzagPositions[64] = {	 0,  1,  8, 16,  9,  2,  3, 10,
											17, 24, 32, 25, 18, 11,  4,  5,
											12, 19, 26, 33, 40, 48, 41, 34,
											27, 20, 13,  6,  7, 14, 21, 28,
											35, 42, 49, 56, 57, 50, 43, 36,
											29, 22, 15, 23, 30, 37, 44, 51,
											58, 59, 52, 45, 38, 31, 39, 46,
											53, 60, 61, 54, 47, 55, 62, 63
									  };
byte m_tabClzLut[] = { 
          8,7,6,6,5,5,5,5, 
          4,4,4,4,4,4,4,4, 
          3,3,3,3,3,3,3,3, 
          3,3,3,3,3,3,3,3, 
          2,2,2,2,2,2,2,2, 
          2,2,2,2,2,2,2,2, 
          2,2,2,2,2,2,2,2, 
          2,2,2,2,2,2,2,2, 
          1,1,1,1,1,1,1,1, 
          1,1,1,1,1,1,1,1, 
          1,1,1,1,1,1,1,1, 
          1,1,1,1,1,1,1,1, 
          1,1,1,1,1,1,1,1, 
          1,1,1,1,1,1,1,1, 
          1,1,1,1,1,1,1,1, 
          1,1,1,1,1,1,1,1, 
          0,0,0,0,0,0,0,0, 
          0,0,0,0,0,0,0,0, 
          0,0,0,0,0,0,0,0, 
          0,0,0,0,0,0,0,0, 
          0,0,0,0,0,0,0,0, 
          0,0,0,0,0,0,0,0, 
          0,0,0,0,0,0,0,0, 
          0,0,0,0,0,0,0,0, 
          0,0,0,0,0,0,0,0, 
          0,0,0,0,0,0,0,0, 
          0,0,0,0,0,0,0,0, 
          0,0,0,0,0,0,0,0, 
          0,0,0,0,0,0,0,0, 
          0,0,0,0,0,0,0,0, 
          0,0,0,0,0,0,0,0, 
          0,0,0,0,0,0,0,0 
        };
short		m_tabBufferDatablocs[64];
uint		m_nFlux = 0;
int			m_nFluxBitIndex = 0;
int			m_nFluxIndex = 0;
bool		m_bImageComplete = 0;
int			m_nImageFormat = 0;
int			m_nResolution = 0;
int			m_nImageType = 0;
int			m_nModeQuantificateur = 0;
int			m_nFrameIndex = 0;
int			m_nTotalTranche = 0;
int			m_nTrancheIndex = 0;
int			m_nTotalBloc = 0;
int			m_nLargeur = 0;
int			m_nHauteur = 0;
int			m_nTailleLignePixel = 0;
byte*		m_tabFlux = NULL;
Tranche*	m_stTranche = NULL;
ushort*		m_tabPixelDataRGB565 = NULL;

// R�sum� : Lib�re la m�moire allou�e pour l'image d�cod�e
// Syntaxe :
//ImageDecodeLibere (<nData> est entier syst�me)
//
// Param�tres :
//	nData (entier syst�me) : Pointeur des donn�es de l'image d�cod�e
// Valeur de retour :
// 	bool�en : Vrai si la lib�ration a �t� correctement effectu�e, Faux sinon
//
BOOL WDEXPORT ImageDecodeLibere(ushort * nData) {

	// Si le pointeur est valide
	if (nData) {

		// Tente de lib�rer la m�moire
		try {
			delete[] nData;
		} catch(...) {
			return Faux;
		}
	}

	return Vrai;
}

// R�sum� : D�code un flux de donn�es et retourne les pixels correspondant
// Syntaxe :
//ImageDecode (<tabFlux> est tableau, <nTailleFlux> est entier, <stImageDecodee> est ImageDecodee)
//
// Param�tres :
//	tabFlux (tableau d'octets) : Flux de donn�es � d�coder
//  nTailleFlux (entier) : Taille (en octets) du flux de donn�es
//  stImageDecodee (ImageDecodee) (Sortie) : Informations et donn�es de l'image d�cod�e
// Valeur de retour :
// 	bool�en : Vrai si l'image a �t� correctement d�cod�e, Faux sinon
//
BOOL WDEXPORT ImageDecode(const byte * tabFlux, uint nTailleFlux, ImageDecodee * stImageDecodee) {

	BOOL bResultat = Faux;
	
	// V�rifie la taille du flux
	if (! (nTailleFlux > 0)) { 
		return Faux; 
	}

	// V�rifie le flux
	if (! tabFlux) {
		return Faux;
	}

	// V�rifie la structure
	if (! stImageDecodee) {
		return Faux;
	}

	// Copie l'adresse du flux
	m_tabFlux = (byte *)tabFlux;

	// Traite le flux
	bResultat = FluxTraite((int) (nTailleFlux), stImageDecodee);

	return bResultat;
}

// Traite les donn�es du flux
BOOL FluxTraite(int nTailleFlux, ImageDecodee * stImageDecodee) {

	BOOL	bResultat				= Faux;
	uint	nModeQuantificateur		= 0;
	uint	nAcCoefficients			= 0;
	uint	nMacroblocVide			= 0;
	BOOL	blockY0HasAcComponents	= Faux;
	BOOL	blockY1HasAcComponents	= Faux;
	BOOL	blockY2HasAcComponents	= Faux;
	BOOL	blockY3HasAcComponents	= Faux;
	BOOL	blockCbHasAcComponents	= Faux;
	BOOL	blockCrHasAcComponents	= Faux;
	BOOL	bErreur					= Faux;

	m_nFluxBitIndex 		= 32;
	m_nFlux 				= 0;
	m_nFluxIndex 			= 0;
	m_nTrancheIndex 		= 0;
	m_bImageComplete 		= Faux;
	m_nModeQuantificateur	= 0;

	while (!m_bImageComplete && m_nFluxIndex < (nTailleFlux >> 2)) {

		// Lecture de l'ent�te
		EnteteLit();

		// Si la r�ception de l'image n'est pas compl�t
		if (!m_bImageComplete) {

			// On parcourt chaque macrobloc contenu dans le flux
			for(int nTotal = 0; nTotal < m_nTotalBloc; nTotal ++) {

				nMacroblocVide = FluxDonneesLit(1);

				if (nMacroblocVide == 0) {

					// Lecture des coefficients YCbCr
					nAcCoefficients = FluxDonneesLit(8);
					
					blockY0HasAcComponents = (nAcCoefficients >> 0 & 1) == 1;
					blockY1HasAcComponents = (nAcCoefficients >> 1 & 1) == 1;
					blockY2HasAcComponents = (nAcCoefficients >> 2 & 1) == 1;
					blockY3HasAcComponents = (nAcCoefficients >> 3 & 1) == 1;
					blockCbHasAcComponents = (nAcCoefficients >> 4 & 1) == 1;
					blockCrHasAcComponents = (nAcCoefficients >> 5 & 1) == 1;
					
					// V�rifie si le quantificateur a chang�
					if (((nAcCoefficients >> 6) & 1) == 1) {
						
						// Lit le nouveau quantificateur
						nModeQuantificateur 	= FluxDonneesLit(2);
						m_nModeQuantificateur 	= (int)((nModeQuantificateur < 2) ? ~nModeQuantificateur : nModeQuantificateur);
					}
					
					// Bloc Y0
					BlocOctetsRecupere(blockY0HasAcComponents);
					if(!TransformationInverse(nTotal, 0)) {
						bErreur = Vrai;
						break;
					}
					
					// Bloc Y1
					BlocOctetsRecupere(blockY1HasAcComponents);
					if(!TransformationInverse(nTotal, 1)) {
						bErreur = Vrai;
						break;
					}
					
					// Bloc Y2
					BlocOctetsRecupere(blockY2HasAcComponents);
					if(!TransformationInverse(nTotal, 2)) {
						bErreur = Vrai;
						break;
					}
					
					// Bloc Y3
					BlocOctetsRecupere(blockY3HasAcComponents);
					if(!TransformationInverse(nTotal, 3)) {
						bErreur = Vrai;
						break;
					}
					
					// Bloc Cb
					BlocOctetsRecupere(blockCbHasAcComponents);
					if(!TransformationInverse(nTotal, 4)) {
						bErreur = Vrai;
						break;
					}
					
					// Bloc Cr
					BlocOctetsRecupere(blockCrHasAcComponents);
					if(!TransformationInverse(nTotal, 5)) {
						bErreur = Vrai;
						break;
					}
				}
			}

			// Si une erreur a eu lieu
			if (bErreur) {
				break;		}

			// Recompose la tranche d'image
			TrancheCompose();
		}
	}

	// Si aucune erreur n'a eu lieu
	if (!bErreur) {

		// Renvoie les donn�es
		stImageDecodee->nLargeur	= (uint)m_nLargeur;
		stImageDecodee->nHauteur	= (uint)m_nHauteur;
		stImageDecodee->nDataSize	= (uint)(m_nLargeur * m_nHauteur * 2);		
		
		// Pr�pare le buffer de retour
		stImageDecodee->nData		= new ushort[m_nLargeur * m_nHauteur];

		// Copie les pixels
		memcpy(stImageDecodee->nData, m_tabPixelDataRGB565, stImageDecodee->nDataSize);

		// Retour
		bResultat = Vrai;

	} else {
		bResultat = Faux;
	}

	// Lib�re les pixels
	if (m_tabPixelDataRGB565) {
		delete[] m_tabPixelDataRGB565;
		m_tabPixelDataRGB565 = NULL;
	}

	// Lib�re la tranche
	if (m_stTranche) {
		delete[] m_stTranche->Macroblocs;
		m_stTranche->Macroblocs = NULL;
		delete m_stTranche;
		m_stTranche = NULL;
	}

	return bResultat;
}

// Lit l'ent�te d'une trame
void EnteteLit() {

	uint nCode = 0;
	uint nStartCode = 0;

	// Alignement des donn�es si n�cessaire
	FluxDonneesAligne();
	
	// Lecture du "startcode" (22bits)
	nCode = FluxDonneesLit(22);
	nStartCode = (uint)(nCode & ~0x1F);

	// Si le "startcode" est correct
	if (nStartCode == 32) {

		// Si le flag 0x1f est pr�sent dans le code
		if ((nCode & 0x1f) == 0x1f) {

			// l'image est totalement re�ue
			m_bImageComplete = Vrai;
		} else {

			// Si on n'a pas encore d�cod� une seule tranche de l'image
			if (m_nTrancheIndex == 0) {

				// R�cup�re les informations sur l'image
				m_nImageFormat 			= (int)FluxDonneesLit(2);
				m_nResolution  			= (int)FluxDonneesLit(3);
				m_nImageType   			= (int)FluxDonneesLit(3);
				m_nModeQuantificateur   = (int)FluxDonneesLit(5);
				m_nFrameIndex   		= (int)FluxDonneesLit(32);

				// D�termine les dimensions de l'image en fonction du format et de la r�solution
				switch(m_nImageFormat) {
					
					// CIF
					case 1 :
						m_nLargeur = CONST_WidthCif << (m_nResolution - 1);
						m_nHauteur = CONST_HeightCif << (m_nResolution - 1);
						break;
					
					// VGA
					case 2 :
						m_nLargeur = CONST_WidthVga << (m_nResolution - 1);
						m_nHauteur = CONST_HeightVga << (m_nResolution - 1);
						break;

					default :
						break;
				}

				// Autres informations pour le d�codage
				m_nTailleLignePixel = m_nLargeur << 1;
				m_nTotalTranche		= m_nHauteur >> 4;
				m_nTotalBloc		= m_nLargeur >> 4;

				if (!m_stTranche || m_stTranche->Occurrence != (uint)m_nTotalBloc) {

					// Lib�re la tranche pr�c�dente
					if (m_stTranche) {
						delete [] m_stTranche->Macroblocs;
						delete m_stTranche;
						m_stTranche = NULL;
					}

					// Alloue une tranche
					m_stTranche		= new Tranche;

					// Alloue le buffer des pixels
					if (m_tabPixelDataRGB565)
						delete [] m_tabPixelDataRGB565;

					m_tabPixelDataRGB565 = new ushort[m_nLargeur * m_nHauteur];

					// Alloue les macroblocs
					m_stTranche->Macroblocs = new Macrobloc[m_nTotalBloc];
					m_stTranche->Occurrence = (uint)m_nTotalBloc;
				}

			} else {

				// Lit le nouveau mode de quantification
				m_nModeQuantificateur = (int)FluxDonneesLit(5);
			}

			// Tranche suivante
			m_nTrancheIndex++;
		}
	}
}

// Lit des bits dans le flux
uint FluxDonneesLit(int nTotal) {

	uint	nData = 0;
	int		nRest = 0;
	uint *  pData = (uint *) m_tabFlux;

	// D�termine le reste des bits non lus de la fois pr�c�dente
	nRest = 32 - m_nFluxBitIndex;

	// Tant que les donn�es � lire sont plus grandes que ce qui reste
	while (nTotal > nRest) {

		// On r�cup�re le reste des donn�es
		nData = (nData << nRest) | (m_nFlux >> m_nFluxBitIndex);

		// D�cr�mente ce qu'il y a � lire
		nTotal -= nRest;

		// R�cup�re les donn�es suivantes
		m_nFlux = pData[m_nFluxIndex];
		m_nFluxBitIndex = 0;
		
		// Recalcule ce qui reste � lire
		nRest = 32 - m_nFluxBitIndex;
		m_nFluxIndex ++;
	}

	// Si il reste encore des donn�es � lire
	if (nTotal > 0) {

		// Ajoute les bits restants
		nData = (nData << nTotal) | (m_nFlux >> (32 - nTotal));

		// Enl�ve les bits lus de la trame
		m_nFlux <<= nTotal;

		// Et d�cale l'index en cons�quence
		m_nFluxBitIndex += nTotal;
	}

	pData = NULL;

	return nData;
}

// R�cup�re les donn�es d'un bloc
void BlocOctetsRecupere(BOOL bAcCoefficientsDisponible) {

	int		nExec = 0;
	int		nNiveau = 0;
	int		nMatrix = 0;
	BOOL	bDernier = Faux;
	int		nZigZag = 0;
	uint	nDcCoefficient = 0;
	
	// RAZ
	memset(m_tabBufferDatablocs, 0, 64 * sizeof(short));

	// Lecture du coefficient DC
	nDcCoefficient = FluxDonneesLit(10);

	// Si le mode de quantification est valide
	if (m_nModeQuantificateur == CONST_TableQuantization) {

		//
		m_tabBufferDatablocs[0] = (short)(nDcCoefficient * m_tabQuantificateur[0]);

		if (bAcCoefficientsDisponible) {

			// D�code les octets du bloc
			DecodeOctets(&nExec, &nNiveau, &bDernier);
			while (bDernier == Faux) {

				nZigZag							+= nExec + 1;
				nMatrix							= m_tabZigzagPositions[nZigZag];
				nNiveau							*= m_tabQuantificateur[nMatrix];
				m_tabBufferDatablocs[nMatrix]	= (short)nNiveau;

				// Suite du d�codage
				DecodeOctets(&nExec, &nNiveau, &bDernier);
			}
		}
	}
}

// Effectue les transformations n�cessaire pour le d�codage de l'image
BOOL TransformationInverse(int nIndexMacrobloc, int nIndexDatabloc) {

	int tabTravail[64];
	int tabData[64];
	int z1 = 0, z2 = 0, z3 = 0, z4 = 0, z5 = 0;
	int tmp0 = 0, tmp1 = 0, tmp2 = 0, tmp3 = 0;
	int tmp10 = 0, tmp11 = 0, tmp12 = 0, tmp13 = 0;
	int nDcVal = 0;
	int nPointer = 0;

	for(int i = 0; i < 8; i++) {

		if (m_tabBufferDatablocs[nPointer + 8] == 0 &&
			m_tabBufferDatablocs[nPointer + 16] == 0 &&
			m_tabBufferDatablocs[nPointer + 24] == 0 &&
			m_tabBufferDatablocs[nPointer + 32] == 0 &&
			m_tabBufferDatablocs[nPointer + 40] == 0 &&
			m_tabBufferDatablocs[nPointer + 48] == 0 &&
			m_tabBufferDatablocs[nPointer + 56] == 0) {

			nDcVal = m_tabBufferDatablocs[nPointer] << PASS1_BITS;

			tabTravail[nPointer + 0] = nDcVal;
			tabTravail[nPointer + 8] = nDcVal;
			tabTravail[nPointer + 16] = nDcVal;
			tabTravail[nPointer + 24] = nDcVal;
			tabTravail[nPointer + 32] = nDcVal;
			tabTravail[nPointer + 40] = nDcVal;
			tabTravail[nPointer + 48] = nDcVal;
			tabTravail[nPointer + 56] = nDcVal;

			nPointer ++;
			continue;
		}

		z2 = m_tabBufferDatablocs[nPointer + 16];
		z3 = m_tabBufferDatablocs[nPointer + 48];

		z1 = (z2 + z3) * FIX_0_541196100;
		tmp2 = z1 + (z3 * -FIX_1_847759065);
		tmp3 = z1 + (z2 * FIX_0_765366865);
		
		z2 = m_tabBufferDatablocs[nPointer];
		z3 = m_tabBufferDatablocs[nPointer + 32];

		tmp0 = (z2 + z3) << CONST_BITS;
		tmp1 = (z2 - z3) << CONST_BITS;

		tmp10 = tmp0 + tmp3;
		tmp13 = tmp0 - tmp3;
		tmp11 = tmp1 + tmp2;
		tmp12 = tmp1 - tmp2;
		
		tmp0 = m_tabBufferDatablocs[nPointer + 56];
		tmp1 = m_tabBufferDatablocs[nPointer + 40];
		tmp2 = m_tabBufferDatablocs[nPointer + 24];
		tmp3 = m_tabBufferDatablocs[nPointer + 8];
		
		z1 = tmp0 + tmp3;
		z2 = tmp1 + tmp2;
		z3 = tmp0 + tmp2;
		z4 = tmp1 + tmp3;
		z5 = (z3 + z4) * FIX_1_175875602;
		
		tmp0 = tmp0 * FIX_0_298631336;
		tmp1 = tmp1 * FIX_2_053119869;
		tmp2 = tmp2 * FIX_3_072711026;
		tmp3 = tmp3 * FIX_1_501321110;
		z1 = z1 * -FIX_0_899976223;
		z2 = z2 * -FIX_2_562915447;
		z3 = z3 * -FIX_1_961570560;
		z4 = z4 * -FIX_0_390180644;
		
		z3 += z5;
		z4 += z5;
		
		tmp0 += z1 + z3;
		tmp1 += z2 + z4;
		tmp2 += z2 + z3;
		tmp3 += z1 + z4;

		tabTravail[nPointer + 0] = ((tmp10 + tmp3 + (1 << F1)) >> F2);
		tabTravail[nPointer + 56] = ((tmp10 - tmp3 + (1 << F1)) >> F2);
		tabTravail[nPointer + 8] = ((tmp11 + tmp2 + (1 << F1)) >> F2);
		tabTravail[nPointer + 48] = ((tmp11 - tmp2 + (1 << F1)) >> F2);
		tabTravail[nPointer + 16] = ((tmp12 + tmp1 + (1 << F1)) >> F2);
		tabTravail[nPointer + 40] = ((tmp12 - tmp1 + (1 << F1)) >> F2);
		tabTravail[nPointer + 24] = ((tmp13 + tmp0 + (1 << F1)) >> F2);
		tabTravail[nPointer + 32] = ((tmp13 - tmp0 + (1 << F1)) >> F2);
		
		nPointer ++;
	}

	nPointer = 0;

	for(int i = 0; i < 8; i++) {

		z2 = tabTravail[nPointer + 2];
		z3 = tabTravail[nPointer + 6];
		
		z1 = (z2 + z3) * FIX_0_541196100;
		tmp2 = z1 + (z3 * -FIX_1_847759065);
		tmp3 = z1 + (z2 * FIX_0_765366865);
		
		tmp0 = (tabTravail[nPointer + 0] + tabTravail[nPointer + 4]) << CONST_BITS;
		tmp1 = (tabTravail[nPointer + 0] - tabTravail[nPointer + 4]) << CONST_BITS;
		
		tmp10 = tmp0 + tmp3;
		tmp13 = tmp0 - tmp3;
		tmp11 = tmp1 + tmp2;
		tmp12 = tmp1 - tmp2;
		
		tmp0 = tabTravail[nPointer + 7];
		tmp1 = tabTravail[nPointer + 5];
		tmp2 = tabTravail[nPointer + 3];
		tmp3 = tabTravail[nPointer + 1];
		
		z1 = tmp0 + tmp3;
		z2 = tmp1 + tmp2;
		z3 = tmp0 + tmp2;
		z4 = tmp1 + tmp3;
		
		z5 = (z3 + z4) * FIX_1_175875602;
		
		tmp0 = tmp0 * FIX_0_298631336;
		tmp1 = tmp1 * FIX_2_053119869;
		tmp2 = tmp2 * FIX_3_072711026;
		tmp3 = tmp3 * FIX_1_501321110;
		z1 = z1 * -FIX_0_899976223;
		z2 = z2 * -FIX_2_562915447;
		z3 = z3 * -FIX_1_961570560;
		z4 = z4 * -FIX_0_390180644;
		
		z3 += z5;
		z4 += z5;
		
		tmp0 += z1 + z3;
		tmp1 += z2 + z4;
		tmp2 += z2 + z3;
		tmp3 += z1 + z4;
		
		tabData[nPointer + 0] = (int)((tmp10 + tmp3) >> F3);
		tabData[nPointer + 7] = (int)((tmp10 - tmp3) >> F3);
		tabData[nPointer + 1] = (int)((tmp11 + tmp2) >> F3);
		tabData[nPointer + 6] = (int)((tmp11 - tmp2) >> F3);
		tabData[nPointer + 2] = (int)((tmp12 + tmp1) >> F3);
		tabData[nPointer + 5] = (int)((tmp12 - tmp1) >> F3);
		tabData[nPointer + 3] = (int)((tmp13 + tmp0) >> F3);
		tabData[nPointer + 4] = (int)((tmp13 - tmp0) >> F3);
		
		nPointer += 8;
	}

	// Transf�re les donn�es
	try {
		memcpy(m_stTranche->Macroblocs[nIndexMacrobloc].DataBlocs[nIndexDatabloc].Data, tabData, 64 * sizeof(int));
	} catch(...) {
		return Faux;
	}

	return Vrai;
}

// Recompose une tranche d'image
void TrancheCompose() {

	int u = 0, ug = 0, ub = 0;
	int v = 0, vg = 0, vr = 0;
	int r = 0, g = 0, b = 0;
	int rs = 0, gs = 0, bs = 0;
	int nLumaElementIndex1 = 0; 	
	int nLumaElementIndex2 = 0; 	
	int nChromaOffset = 0;	   	
	int nDataIndex1 = 0;		   	
	int nDataIndex2 = 0;		   	
	int nLumaElementVal1 = 0;   	
	int nLumaElementVal2 = 0;   	
	int nChromaBleuVal = 0;	   	
	int nChromaRougeVal = 0;	   	
	int nChromaIndex = 0; 		
	int nDeltaIndex = 0;
	int tabChromaQuadraOffsets[4]		= {0, 4, 32, 36};
	int tabPixelDataQuadraOffsets[4]	= {0, CONST_BlockWidth, m_nLargeur * CONST_BlockWidth, (m_nLargeur * CONST_BlockWidth) + CONST_BlockWidth};
	int nImageDataOffset				= (m_nTrancheIndex - 1) * m_nLargeur * 16;
	Macrobloc * stMacrobloc				= NULL;

	for(int i = 0; i < (int)m_stTranche->Occurrence; i++) {
		stMacrobloc = &(m_stTranche->Macroblocs[i]);

		for (int nVertical = 0; nVertical < CONST_BlockWidth / 2; nVertical++) {

			nChromaOffset 		= nVertical * CONST_BlockWidth;
			nLumaElementIndex1 	= nVertical * CONST_BlockWidth * 2;
			nLumaElementIndex2 	= nLumaElementIndex1 + CONST_BlockWidth;		

			nDataIndex1 		= nImageDataOffset + (2 * nVertical * m_nLargeur);
			nDataIndex2 		= nDataIndex1 + m_nLargeur;

			for (int nHorizontal = 0; nHorizontal < CONST_BlockWidth / 2; nHorizontal++) {
				for (int nQuadra = 0; nQuadra < 4; nQuadra++) {

					nChromaIndex  		= nChromaOffset + tabChromaQuadraOffsets[nQuadra] + nHorizontal;
					nChromaBleuVal  	= stMacrobloc->DataBlocs[4].Data[nChromaIndex];
					nChromaRougeVal 	= stMacrobloc->DataBlocs[5].Data[nChromaIndex];
					
					u = nChromaBleuVal - 128;
					ug = 88 * u;
					ub = 454 * u;
					
					v = nChromaRougeVal - 128;
					vg = 183 * v;
					vr = 359 * v;

					for (int nPixel = 0; nPixel < 2; nPixel++) {

						nDeltaIndex 	 = 2 * nHorizontal + nPixel;
						nLumaElementVal1 = (stMacrobloc->DataBlocs[nQuadra].Data[(nLumaElementIndex1 + nDeltaIndex)] << 8);
						nLumaElementVal2 = (stMacrobloc->DataBlocs[nQuadra].Data[(nLumaElementIndex2 + nDeltaIndex)] << 8);
												
						r = Sature5(nLumaElementVal1 + vr);
						g = Sature6(nLumaElementVal1 - ug - vg);
						b = Sature5(nLumaElementVal1 + ub);
						
						m_tabPixelDataRGB565[(nDataIndex1 + tabPixelDataQuadraOffsets[nQuadra] + nDeltaIndex)] = (ushort)((r << 11) | (g << 5) | b);

						r = Sature5(nLumaElementVal2 + vr);
						g = Sature6(nLumaElementVal2 - ug - vg);
						b = Sature5(nLumaElementVal2 + ub);
						
						m_tabPixelDataRGB565[(nDataIndex2 + tabPixelDataQuadraOffsets[nQuadra] + nDeltaIndex)] = (ushort)((r << 11) | (g << 5) | b);
					}
				}
			}
		}

		nImageDataOffset += 16;
	}
}

void DecodeOctets(int * nExec, int * nNiveau, BOOL * bDernier) {

	uint  nCodeFlux = 0;
	int	  nTailleFlux = 0;
	int   nTotalZero = 0;
	int   nTemp = 0;
	int   nSigne = 0;
	int   nZeroMin1 = 0;
	int   nLocal = 0;

	// Les bits dans les donn�es sont en fait compos�s de deux types :
	// - le 'run field' (nExec) : contient des informations sur le nombre de z�ros cons�cutifs
	// - le 'level field' (nNiveau) : contient la valeur non nulle, qui peut �tre n�gative ou positive
	
	nCodeFlux 	= FluxDonneesPeek(m_tabFlux, 32);
	
	// D�termine le nombre de z�ros cons�cutifs dans le zig-zag ('run field')
	// Sur une s�quence de bits :
	// 00001111....
	// - [1] le nombre de z�ros � gauche est 4
	//   (la valeur de recherche est donc 00001)
	// - [2] recherche la valeur additionnelle (pour 00001 c'est 3 bits de plus (5 + 3 = 8)
	// - [3] calcule la valeur du champ ('run') (pour 00001, c'est (111) + 8)

	nTotalZero  = CLZ(nCodeFlux);										// [1]
	nZeroMin1	= nTotalZero - 1;
	nLocal 		= nTotalZero + 1;
	nCodeFlux   = nCodeFlux << nLocal;									// [2]
	nTailleFlux += nLocal;												//
	
	if (nTotalZero > 1) {
		nLocal 		= 32 - nZeroMin1;
		nTemp 		= (int)(nCodeFlux >> nLocal);						// [2]
		nCodeFlux 	<<= nZeroMin1;				
		nTailleFlux += nZeroMin1;
		*nExec 		= nTemp + (1 << nZeroMin1);							// [3]
	} else {
		*nExec 		= nTotalZero;										// [3]
	}

	// D�termine la valeur non nulle ('level field')
	// Sur une s�quence de bits :
	// 000011111....
	// - [1] le nombre de z�ros � gauche est 4
	//   (la valeur de recherche est donc 00001)
	// - [2] recherche la valeur additionnelle (pour 00001 c'est 4 bits de plus (le dernier bit est le bit de signe)
	// - [3] calcule la valeur du champ ('level') (pour 00001, c'est (xxx) + 8, multipli� par le signe)
	
	nTotalZero  = CLZ(nCodeFlux);										// [1]
	nZeroMin1	= nTotalZero - 1;	
	nLocal 		= nTotalZero + 1;
	nCodeFlux   = nCodeFlux << nLocal;									// [2]
	nTailleFlux = nTailleFlux + nLocal;									//

	if (nTotalZero == 1) {
		
		// Si la valeur de recherche est 01, fin du buffer
		*nExec 		= 0;
		*bDernier 	= Vrai;
	} else {
		if (nTotalZero == 0) {
			
			nTotalZero 	= 1;
			nZeroMin1	= nTotalZero - 1;
			nTemp 		= 1;
		}
		
		nTailleFlux = nTailleFlux + nTotalZero;
		nLocal		= 32 - nTotalZero;
		nCodeFlux 	= nCodeFlux >> nLocal;								// [2]
		nSigne 		= (int)(nCodeFlux & 1);								// D�termine le signe
		
		if (nTotalZero != 0) {
			nTemp = (int)(nCodeFlux >> 1);								// Prend en compte le bit de signe
			nTemp += (int)(1 << nZeroMin1);								// [3]
		}
		
		*nNiveau = (nSigne == 1) ? -nTemp : nTemp;						// Calcule la valeur du champ avec le signe
		*bDernier = Faux;
	}
	
	FluxDonneesLit(nTailleFlux);
}

// Lit les donn�es sans changer la position dans le flux
uint FluxDonneesPeek(byte * tabFlux, int nTotal) {

	uint	nData = 0;
	uint *  pData = (uint *) tabFlux;

	// Conserve les index courants
	uint  nFlux			= m_nFlux;
	int   nFluxBitIndex	= m_nFluxBitIndex;

	// D�termine le reste des bits non lus de la fois pr�c�dente
	int	  nRest			= 32 - nFluxBitIndex;

	// Tant que les donn�es � lire sont plus grandes que ce qui reste
	while (nTotal > nRest) {

		// On r�cup�re le reste des donn�es
		nData = (nData << nRest) | (nFlux >> nFluxBitIndex);
		
		// D�cr�mente ce qu'il y a lire
		nTotal -= nRest;
		
		// R�cup�re les donn�es suivante
		nFlux = pData[m_nFluxIndex];
		nFluxBitIndex = 0;
		
		// Recalcule ce qui reste � lire
		nRest = (32 - nFluxBitIndex);
	}

	// Si il reste encore des donn�es � lire
	if (nTotal > 0) {

		// Ajoute les bits restant � lire
		nRest = 32 - nTotal;
		nData = (nData << nTotal) | (nFlux >> nRest);
	}

	pData = NULL;

	return nData;
}

// Aligne les donn�es sur 32 bits si n�cessaire
void FluxDonneesAligne() {

	int nTailleAligne = 0;
	int nTailleActuelle = 0;
	int nTaille = 0;

	// R�cup�re la position actuelle dans le flux des donn�es
	nTailleActuelle = m_nFluxBitIndex;

	// Si on a d�marr� la lecture
	if (nTailleActuelle > 0) {

		// V�rifie que la position est align�e
		nTailleAligne = nTailleActuelle & ~7;
		if (nTailleAligne != nTailleActuelle) {

			// Aligne la taille
			nTailleAligne += 0x08;
			nTaille = nTailleAligne - nTailleActuelle;

			// Relit la donn�e
			m_nFlux <<= nTaille;
			m_nFluxBitIndex = nTailleAligne;
		}
	}
}

// Sature une valeur (RGB565)
int Sature5(int x) {
	if (x < 0) {
		x = 0;
	}

    x >>= 11;
	return x > 0x1f ? 0x1f : x;
}

// Sature une valeur (RGB565)
int Sature6(int x) {
	if (x < 0) {
		x = 0;
	}

    x >>= 10;
	return x > 0x3f ? 0x3f : x;
}

// Renvoie le nombre de bits d'ent�te � 0 d'une valeur ("Count Leading Zeros")
int CLZ(uint nValeur) {

	int nAccum = 0;

    nAccum += m_tabClzLut[nValeur >> 24];
    nAccum += (nAccum == 8) ? m_tabClzLut[(nValeur >> 16) & 0xFF] : 0;
    nAccum += (nAccum == 16) ? m_tabClzLut[(nValeur >> 8) & 0xFF] : 0;
    nAccum += (nAccum == 24) ? m_tabClzLut[nValeur & 0xFF] : 0;

    return nAccum;
}