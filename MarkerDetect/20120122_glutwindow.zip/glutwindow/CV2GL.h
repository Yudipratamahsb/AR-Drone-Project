/****************************************
*	CV2GL.c
*	//OpenCVの画像などを、OpenGLに表示させる関数
*
*****************************************/

#include <stdio.h>
#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <opencv/cxcore.h>

//OpenGL用
#include <GL/glut.h>
//環境によってはGLUT/glut.hかもしれません


//画像のチャネル数、ビット深度などのチェック
int CheckImage(IplImage *srcImage);

//IplImageを描画します。
void DrawIplImageToGLFrameBuffer(IplImage* srcImage);

//OpenGL反転された画像を書いていきます。
void ImageProjection(IplImage* yInvImage);
