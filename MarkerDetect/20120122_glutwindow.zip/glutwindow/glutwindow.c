/*OpenCVのIplImageを、OpenGLのスクリーンに表示するテストプログラム*/



#include <GL/glut.h>
#include "CV2GL.h"	//OpenCVとOpenGLのつなぎ役
/*
** 定数
*/

//ウィンドウサイズをVGAサイズとします。
#define WINDOW_WIDTH (640)
#define WINDOW_HEIGHT (480)
#define IMAGE_WIDTH (640)
#define IMAGE_HEIGHT (480)
#define TIMER_INTERVAL (50)

//#define DEBUG


IplImage* img;
int time=0;

CvCapture* cap;
IplImage* capFrame;

//再描画時に呼ばれる関数
//CallBack function for redraw
void OnDisplay(void)
{
	capFrame=cvQueryFrame(cap);
	cvCopy(capFrame,img,NULL);	

#ifdef DEBUG
	fprintf(stdout,"Size:%d,%d Channel:%d Depth:%d\n",
					img->width,
					img->height,
					(int)img->nChannels,
					(int)img->depth);
#endif	//DEBUG
	DrawIplImageToGLFrameBuffer(img);

/*バッファにOpenCVの画像がコピーされたので、
残りのOpenGL部分を描画します。
glClear(GL_COLOR_BUFFER_BIT)を実行してしまうと、コピーしたのが消えるので注意。
*/
	

	//	
	glutWireTeapot(0.4);


	glutSwapBuffers();
}

//ウィンドウの大きさが変更されたときに呼ばれる関数
//w ウィンドウの横幅
//h ウィンドウの縦幅
//Callback function for resize window
void OnResize(int w, int h)
{
	//ウィンドウサイズが変わっても、ビューポートサイズは変更しない。
	//(画面上はつねに640x480の大きさでOpenCVの画像が描画される)
	glViewport(0, 0, WINDOW_WIDTH,WINDOW_HEIGHT);
	glLoadIdentity();
}

//キーボードが押されたときの処理
//Callback function for keyboard pressed
void OnKeyboard(unsigned char key, int x, int y)
{
	//エスケープキーとかだったらアプリ終了
	switch (key)
	{
		case 'q':
		case 'Q':
		case '\033':  /*ESC Key*/
			exit(0);
  	default:
		break;
	}
}



//
//OpenCVの初期化処理
void initOpenCV()
{
	img=cvLoadImage("00.jpg",1);
	if(NULL==img)
	{
		fprintf(stderr,"Could not load image.\n");
		exit(-1);

	}
	//cap=cvCreateCameraCapture(0);

	cap=cvCaptureFromCAM(-1);
	if(NULL==cap)
	{
		fprintf(stderr,"Could not initialize camera.\n");
		exit(-1);
	}
	
	cvSetCaptureProperty (cap, CV_CAP_PROP_FRAME_WIDTH, IMAGE_WIDTH);
	cvSetCaptureProperty (cap, CV_CAP_PROP_FRAME_HEIGHT, IMAGE_HEIGHT);

}

//OpenCVの片付け処理
void cleanUpOpenCV()
{
	if(NULL!=cap)
	{
		cvReleaseCapture(&cap);
		cap==NULL;

	}
}

void OnTimer(int arg)
{
	glutPostRedisplay();
	glutTimerFunc(TIMER_INTERVAL,OnTimer,1);
}

int main(int argc, char *argv[])
{
	
	//OpenCVの初期化処理。画像の読み込みとかカメラとの接続とか
	initOpenCV();
	

	//ウィンドウサイズと位置の初期化
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(WINDOW_WIDTH,WINDOW_HEIGHT);
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH|GLUT_RGBA);	//RGBモードに設定
	glutCreateWindow(argv[0]);

	//コールバック関数一覧を登録してく
	glutDisplayFunc(OnDisplay);		//再描画処理
	glutReshapeFunc(OnResize);		//リサイズ処理
	glutKeyboardFunc(OnKeyboard);	//キーボード処理

	glutTimerFunc(500,OnTimer,1);
	
	glutMainLoop();

	//後片付け
	cleanUpOpenCV();

	return 0;
}
