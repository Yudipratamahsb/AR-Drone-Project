/****************************************
*	CV2GL.c
*	//OpenCVの画像などを、OpenGLに表示させる関数
*
*****************************************/

#include <stdio.h>
#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <opencv/cxcore.h>

//OpenGL用
#include <GL/glut.h>
//環境によってはGLUT/glut.hかもしれません


//画像のチャネル数、ビット深度などのチェック
int CheckImage(IplImage *srcImage);

//IplImageを描画します。
void DrawIplImageToGLFrameBuffer(IplImage* srcImage,GLfloat xStart,GLfloat yStart,GLfloat zNear,GLfloat drawZlocation);
//OpenGLのバッファに反転された画像を書いていきます。
//yInvImage 描画対象の画像。Y軸が反転されたもの。IPL_DEPTH_8U,3チャネルが対象です。
//drawZlocation 画像のZ位置。Zに合わせてスケーリングします。
void ImageProjection(IplImage* yInvImage,GLfloat xStart,GLfloat yStart,GLfloat zNear,GLfloat drawZlocation);

