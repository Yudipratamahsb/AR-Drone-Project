/*
 * estimateRotTransVector.c
 *
 *  Created on: 2012/01/24
 *      Author: lhaplus8888
 */

#include "estimateRotTransVector.h"


//画像からチェスボードを探し、チェスボードのTranslationVectortとRotation_vectorを求めます。
//エラーあり：−１
//エラーなし：0
int EstimateRotation_TranlationVector(IplImage* img,
										const CvMat* camera_matrix,
										const CvMat* distortion_coeffs,
										CvMat* translation_vector,
										CvMat* rotation_vector)
{
	char funcname[50];
	sprintf(funcname,"@EstimateRotation_TranlationVector");
	//まずは必要条件チェック
	//入力画像　IPL_DEPTH_8U,3チャネルのカラー画像
	if(IPL_DEPTH_8U!=img->depth)
	{
		fprintf(stderr,"image depth must 8U.%s\n",funcname);
		return -1;
	}
	if(3!=img->nChannels)
	{
		fprintf(stderr,"Channel must 3. :%d .%s\n",img->nChannels,funcname);
		return -1;
	}

    if( camera_matrix->rows != 3 || camera_matrix->cols != 3 || CV_MAT_CN(camera_matrix->type) != 1 )
    {
    	fprintf(stderr,"amera_matrix must be 3x3, single-channel floating point matrix.%s\n",funcname);
    	return -1;
    }
    if( distortion_coeffs->rows != 1 || distortion_coeffs->cols != 4 || CV_MAT_CN(distortion_coeffs->type) != 1 )
    {
       	fprintf(stderr,"distortion_coeffs must be 1x4, single-channel floating point matrix.%s\n",funcname);
     	return -1;
    }

    //////////////////チェック終了
    IplImage* workImg;
    IplImage* workImg_gray;
    CvSize pattern_size = cvSize (PAT_COL, PAT_ROW);
    CvPoint3D32f RealPoints[ALL_POINTS];
    CvPoint2D32f *ChessBoardCorners = (CvPoint2D32f *) cvAlloc (sizeof (CvPoint2D32f) * ALL_POINTS);

    CvMat MatRealPoints;
    CvMat MatChessBoardCorners;

    //作業用画像にコピー
    workImg=cvCreateImage(cvGetSize(img),IPL_DEPTH_8U,3);
    cvCopy(img,workImg,NULL);
    workImg_gray=cvCreateImage(cvGetSize(workImg),IPL_DEPTH_8U,1);

    //デフォルトではIplImageのならびはBGRになってる
    cvCvtColor(workImg,workImg_gray,CV_BGR2GRAY);

    //まずはチェスボードがありそうかどうかを簡易チェック。
    int ChessBoardFound=0;
    ChessBoardFound= cvCheckChessboard(workImg_gray,cvSize(PAT_ROW,PAT_COL));
    if(1!=ChessBoardFound)
    {
    	//チェスボードが無かったので終了
    	fprintf(stderr,"ChessBoard not found  %s\n ",funcname);
    	cvReleaseImage(&workImg);
    	cvReleaseImage(&workImg_gray);
    	return -1;
    }
    //チェスボードがありそうなので処理続行。

    int row=0;
    int col=0;
    //チェスボードの３次元座標の設定。
    //関数毎に実行する必要はありませんが、そんなに時間がかかる処理でもないので含めてしまいます
    for (row = 0; row < PAT_ROW; row++)
    {
    	for (col = 0; col < PAT_COL; col++)
    	{
    		RealPoints[row * PAT_COL + col].x = col * CHESS_SIZE;
    		RealPoints[row * PAT_COL + col].y =	-1*row * CHESS_SIZE;
    		RealPoints[row * PAT_COL + col].z = 0.0;
    	}
    }

    //配列の集まりをCvMatで参照できるようにする
    cvInitMatHeader (&MatRealPoints, ALL_POINTS, 3, CV_32FC1, RealPoints,CV_AUTOSTEP);

    //-------------------------
    //チェスボードの検出準備
    //-------------------------

    //チェスボードのコーナー座標を格納するCvMatを初期化しておく
    cvInitMatHeader (&MatChessBoardCorners, ALL_POINTS, 1, CV_32FC2,ChessBoardCorners,CV_AUTOSTEP);

    //チェスボードの各コーナーをさがして、その後サブピクセル精度にする
    int CornerCount=0;
    ChessBoardFound = cvFindChessboardCorners (workImg, pattern_size, &ChessBoardCorners[0], &CornerCount,CV_CALIB_CB_ADAPTIVE_THRESH);
    cvCvtColor(img,workImg_gray,CV_BGR2GRAY);
    cvFindCornerSubPix (workImg_gray, &ChessBoardCorners[0], CornerCount,
    					cvSize (3, 3), cvSize (-1, -1), cvTermCriteria (CV_TERMCRIT_ITER | CV_TERMCRIT_EPS, 20, 0.03));

    //Translation vectorとRotation vector を求める。
    cvFindExtrinsicCameraParams2 (&MatRealPoints, &MatChessBoardCorners, camera_matrix, distortion_coeffs, rotation_vector, translation_vector,0);

    //この関数内で生成した変数の後片付け
    cvReleaseImage(&workImg);
    cvReleaseImage(&workImg_gray);



#ifdef DEBUG
    //TranslationVectorとかを表示する


    CvMat* rotation_matrix=cvCreateMat (3, 3, CV_32FC1);

    cvRodrigues2(rotation_vector,rotation_matrix,NULL);

    //Rotation matrix表示。そのあとベクトル形式で表示。
    fprintf(stderr,"Rotation Matrix\n");

    float val;
    for(row=0;row<3;row++)
    {
    	for(col=0;col<3;col++)
    	{
    		val=cvmGet(rotation_matrix,row,col);
    		fprintf(stderr,"test[%d][%d]=%f;\t",row,col,val);
    	}
    	fprintf(stderr,"\n");
    }
    fprintf(stderr,"\n");

    cvReleaseMat(&rotation_matrix);

    fprintf(stderr,"Translation vector\n");
    for(col=0;col<3;col++)
    {
    	val=cvmGet(rotation_vector,0,col);
    	fprintf(stderr,"%g\t",val);
    }
   fprintf(stderr,"\n");

   //Translation vectorも表示
   float tx,ty,tz;
   tx=cvmGet(translation_vector,0,0);
   ty=cvmGet(translation_vector,0,1);
   tz=cvmGet(translation_vector,0,2);
   fprintf(stderr,"Translation Vector\n");
   fprintf(stderr,"X:%f\tY:%f\tZ:%f\n",tx,ty,tz);


   //カメラ内部パラメータ
   float fx,fy,cx,cy;
   fx=cvmGet(camera_matrix,0,0);//fx
   fy=cvmGet(camera_matrix,1,1);//fy
   cx=cvmGet(camera_matrix,0,2);//cx
   cy=cvmGet(camera_matrix,1,2);//cy
   fprintf(stderr,"Intrinsic\n");
   fprintf(stderr,"Fx:%f\tFy:%f\tCx:%f\tCy:%f\n",fx,fy,cx,cy);
#endif


   //無事に完了したら０。
   return 0;

}
