/*OpenCVのIplImageを、OpenGLのスクリーンに表示するテストプログラム*/



#include <GL/glut.h>
#include "CV2GL.h"	//OpenCVとOpenGLのつなぎ役
#include "estimateRotTransVector.h"
#include "glm.h"



/*
** 定数
*/

//ウィンドウサイズをVGAサイズとします。
#define WINDOW_WIDTH (640)
#define WINDOW_HEIGHT (480)
#define IMAGE_WIDTH (640)
#define IMAGE_HEIGHT (480)
#define TIMER_INTERVAL (100)

#define Z_NEAR (10)
#define Z_FAR (1200.0)

//#define DEBUG


IplImage* img;
int time=0;


//OpenCVで使う系
CvCapture* cap;
IplImage* capFrame;
IplImage* testimg;

GLfloat g_depth=Z_NEAR;

GLfloat g_ImageXStart=0.0f;
GLfloat g_ImageYStart=0.0f;

GLMmodel *Model; //GLMmodel構造体
char *modelname = "pyramid.obj";//ファイル名


/*
OpenCV側で使うグローバル変数
*/


CvMat *rotation_vector;	//回転ベクトルが格納されます
CvMat *translation_vector;		//移動ベクトルが格納されます

CvMat *intrinsic;		//カメラの内部定数(Fx,Fy,Cx,Cy)をファイルから読み込んでおきます
CvMat *distortion;		//ゆがみ係数をファイルからロードして入れておきます


void
SetLinearAttenuationSpotLight( void )
{
    GLfloat light_position[] = { 50,-50,20,1};//, 30, -10, 1.0 };

    GLfloat light_ambient[] = { 0.5, 0.5, 0.5, 1.0 };
    GLfloat light_diffuse[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat light_specular[] = { 1.0, 1.0, 1.0, 1.0 };

    GLfloat spot_dir[] = { -1.0f, -1.0f, -1.0f };

    glLightfv( GL_LIGHT0, GL_POSITION, light_position );

    glLightfv( GL_LIGHT0, GL_AMBIENT, light_ambient );
    glLightfv( GL_LIGHT0, GL_DIFFUSE, light_diffuse );
    glLightfv( GL_LIGHT0, GL_SPECULAR, light_specular );

    glLightf( GL_LIGHT0, GL_CONSTANT_ATTENUATION, 1.0f );
    glLightf( GL_LIGHT0, GL_LINEAR_ATTENUATION, 1.0f / 200.0f );
    glLightf( GL_LIGHT0, GL_QUADRATIC_ATTENUATION, 0.0f );

    glLightfv( GL_LIGHT0, GL_SPOT_DIRECTION, spot_dir );
    glLightf( GL_LIGHT0, GL_SPOT_CUTOFF, 30.0f );
    glLightf( GL_LIGHT0, GL_SPOT_EXPONENT, 2.0f );

    glEnable( GL_LIGHTING );
    glEnable( GL_LIGHT0 );
}


void renderCubePyramid()
{
	/*glBegin (GL_LINES);
	GLfloat axisSize=200;
	glLineWidth(2);
	glColor3f (1,0,0); // X axis is red.
	glVertex3f(0,0,0);
	glVertex3f(axisSize,0,0);
	glColor3f (0,1,0); // Y axis is green.
	glVertex3f(0,0,0);
	glVertex3f(0,axisSize,0);
	glColor3f (0,0,1); // z axis is blue.
	glVertex3f(0,0,0);
	glVertex3f(0,0,axisSize);
	glEnd();			


*/
	SetLinearAttenuationSpotLight();
	//---------- モデル描画 -----------------//
	glmDraw(Model,GLM_NONE);
}




//再描画時に呼ばれる関数
//CallBack function for redraw
void OnDisplay(void)
{
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	capFrame=cvQueryFrame(cap);
	
	int result;
	result=EstimateRotation_TranlationVector(capFrame,intrinsic,distortion,translation_vector,rotation_vector);	
	
	cvFlip(capFrame,img,0);
	//,NULL);	

	

	
	glRasterPos3f(-314.27666,-1*(480-238.061),-5.66146179e+02);//-cX,-(Height/2-cy),-Fxよりちょいすくなめぐらいで
		glDrawPixels(img->width,img->height,
				GL_BGR, GL_UNSIGNED_BYTE,
				img->imageData);
	
/*バッファにOpenCVの画像がコピーされたので、
残りのOpenGL部分を描画します。
glClear(GL_COLOR_BUFFER_BIT)を実行してしまうと、コピーしたのが消えるので注意。
*/
	glColor3f(1.0, 1.0, 1.0);
	glPushMatrix();

	glColor3f(0,1.0,0);
	glLineWidth(3);
	glLoadIdentity();
	
	
	
	double radians = cvNorm(rotation_vector, NULL, CV_L2,NULL); 
	double degrees = radians*180/3.14; 
	
	
	float translate_x=cvmGet(translation_vector,0,0);
	float translate_y=-1*cvmGet(translation_vector,0,1);
	float translate_z=-1*cvmGet(translation_vector,0,2);

	glTranslatef(translate_x,translate_y,translate_z);

	float rotate_x=cvmGet(rotation_vector,0,0);
	float rotate_y=cvmGet(rotation_vector,0,1);
	float rotate_z=cvmGet(rotation_vector,0,2);
	glRotatef(degrees,rotate_x,	-1*rotate_y,	-1*rotate_z);

	fprintf(stderr,"degree:%f\n",degrees);
	
	glPushMatrix();
	renderCubePyramid();
	glPopMatrix();
	
	glPopMatrix();
	glFlush();
}

//ウィンドウの大きさが変更されたときに呼ばれる関数
//w ウィンドウの横幅
//h ウィンドウの縦幅
//Callback function for resize window
void OnResize(int w, int h)
{
	glMatrixMode (GL_PROJECTION);    /* prepare for and then */ 
    glLoadIdentity ();               /* define the projection */
	glFrustum (-320, 320, -240, 240, /* transformation */
                   Z_NEAR, Z_FAR); 
	GLfloat projectionMatrix[16];
			   
	projectionMatrix[0] = 2.0 * 5.65146179e+02 / 640.0;
	projectionMatrix[1] = 0.0;
	projectionMatrix[2] = 0.0;
	projectionMatrix[3] = 0.0;

	projectionMatrix[4] = 0.0;
	projectionMatrix[5] = 2.0 * 5.65146179e+02 / 480.0;//height;
	projectionMatrix[6] = 0.0;
	projectionMatrix[7] = 0.0;
	
	projectionMatrix[8] = 2.0 * ( 3.14276642e+02 / 640.0) - 1.0;
	projectionMatrix[9] = 2.0 * ( 2.38061874e+02/ 480.0 ) - 1.0;	
	projectionMatrix[10] = -( Z_FAR+Z_NEAR ) / ( Z_FAR - Z_NEAR );
	projectionMatrix[11] = -1.0;

	projectionMatrix[12] = 0.0;
	projectionMatrix[13] = 0.0;
	projectionMatrix[14] = -2.0 * Z_NEAR * Z_FAR / ( Z_FAR - Z_NEAR );		
	projectionMatrix[15] = 0.0;
	
	glLoadMatrixf(projectionMatrix);

	//バッファ描画開始位置
	g_ImageXStart=-320.0;
	g_ImageYStart=-240.0;	//-WINDOW_WIDTH/2, WINDOW_WIDTH/2, -WINDOW_HEIGHT/2, WINDOW_HEIGHT/2, /* transformation */
      //             1, 20.0); 
    
	//ウィンドウサイズが変わっても、ビューポートサイズは変更しない。
	//(画面上はつねに640x480の大きさでOpenCVの画像が描画される)
	glMatrixMode (GL_MODELVIEW);  /* back to modelview matrix */
	glViewport(0, 0, WINDOW_WIDTH,WINDOW_HEIGHT);
	glLoadIdentity();
	

	glClear(GL_COLOR_BUFFER_BIT);
	
	
	
}

//キーボードが押されたときの処理
//Callback function for keyboard pressed
void OnKeyboard(unsigned char key, int x, int y)
{
	//エスケープキーとかだったらアプリ終了
	switch (key)
	{
		case 'q':
		case 'Q':
		case '\033':  /*ESC Key*/
			exit(0);
  	default:
		break;
	}
}



//
//OpenCVの初期化処理
void initOpenCV()
{
	img=cvLoadImage("00.jpg",1);
	if(NULL==img)
	{
		fprintf(stderr,"Could not load image.\n");
		exit(-1);

	}
	testimg=cvLoadImage("00.jpg",1);
	if(NULL==img)
	{
		fprintf(stderr,"Could not load image.\n");
		exit(-1);

	}
	
	//cap=cvCreateCameraCapture(0);
	cap=cvCaptureFromCAM(1);
	if(NULL==cap)
	{
		cap=cvCaptureFromCAM(0);
		if(NULL==cap)
		{
			fprintf(stderr,"Could not initialize camera.\n");
			exit(-1);
		}
	}
	
	
	
	cvSetCaptureProperty (cap, CV_CAP_PROP_FRAME_WIDTH, IMAGE_WIDTH);
	cvSetCaptureProperty (cap, CV_CAP_PROP_FRAME_HEIGHT, IMAGE_HEIGHT);

}

//OpenCVの片付け処理
void cleanUpOpenCV()
{
	if(NULL!=cap)
	{
		cvReleaseCapture(&cap);
		cap==NULL;

	}
}

void initCVMat()
{
	rotation_vector = cvCreateMat (1, 3, CV_32FC1);
	translation_vector		= cvCreateMat (1, 3, CV_32FC1);

	intrinsic		= cvCreateMat (3, 3, CV_32FC1);
	distortion		= cvCreateMat (1, 4, CV_32FC1);

	//XMLファイルから読み込み
	CvFileStorage *fs;
	fs = cvOpenFileStorage ("camera.xml", 0, CV_STORAGE_READ);
	if(NULL==fs)
	{
		fprintf(stderr,"Could not camera param file!!¥n");
		
	}
	CvFileNode *param;

	fs = cvOpenFileStorage ("camera.xml", 0, CV_STORAGE_READ);
	param = cvGetFileNodeByName (fs, NULL, "intrinsic");
	intrinsic = (CvMat *) cvRead (fs, param,NULL);
	param = cvGetFileNodeByName (fs, NULL, "distortion");
	distortion = (CvMat *) cvRead (fs, param,NULL);
	cvReleaseFileStorage (&fs);
	cvReleaseFileStorage (&fs);
}



void OnTimer(int arg)
{
	glutPostRedisplay();
	glutTimerFunc(TIMER_INTERVAL,OnTimer,1);
}

int main(int argc, char *argv[])
{
	
	//OpenCVの初期化処理。画像の読み込みとかカメラとの接続とか
	initOpenCV();
	
	initCVMat();
	
	//ウィンドウサイズと位置の初期化
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(WINDOW_WIDTH,WINDOW_HEIGHT);
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH|GLUT_RGBA);//|GLUT_DOUBLE);	//RGBモードに設定
	glutCreateWindow(argv[0]);

	//コールバック関数一覧を登録してく
	glutDisplayFunc(OnDisplay);		//再描画処理
	glutReshapeFunc(OnResize);		//リサイズ処理
	glutKeyboardFunc(OnKeyboard);	//キーボード処理

	glutTimerFunc(500,OnTimer,1);
	glEnable(GL_LIGHTING);
	
	
	//--------- モデル読み込み ----------//
	Model = glmReadOBJ(modelname);//モデルを読み込む
	glmFacetNormals(Model);//面の法線データを計算
	glmVertexNormals(Model, 90);//頂点の法線を計算、スムージング角は９０度
	glmUnitize(Model);//単位化
	glmScale(Model,100);

	glutMainLoop();
	
	//後片付け
	cleanUpOpenCV();

	//---------- 終了処理 ------------------//
	glmDelete(Model);//不要になったら破棄する

	return 0;
}





