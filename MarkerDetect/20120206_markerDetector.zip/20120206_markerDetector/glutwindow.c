/*OpenCVのIplImageを、OpenGLのスクリーンに表示するテストプログラム*/



#include <GL/glut.h>
#include "CV2GL.h"	//OpenCVとOpenGLのつなぎ役
#include "estimateRotTransVector.h"
#include "MarkerFinder.h"

#include "glm.h"



/*
** 定数
*/

//ウィンドウサイズをVGAサイズとします。
#define WINDOW_WIDTH (640)
#define WINDOW_HEIGHT (480)


#define IMAGE_WIDTH (640)
#define IMAGE_HEIGHT (480)
#define TIMER_INTERVAL (100)

#define Z_NEAR (10)
#define Z_FAR (1200.0)

#define MAX_RECTCOUNT 20

//#define DEBUG


IplImage* img;
int time=0;


//OpenCVで使う系
CvCapture* cap;
IplImage* capFrame;
IplImage* testimg;

GLfloat g_depth=Z_NEAR;




GLMmodel *Model; //GLMmodel構造体
char *modelname = "chair.obj";//ファイル名


/*
OpenCV側で使うグローバル変数
*/


CvMat *rotation_vector;	//回転ベクトルが格納されます
CvMat *translation_vector;		//移動ベクトルが格納されます

CvMat *intrinsic;		//カメラの内部定数(Fx,Fy,Cx,Cy)をファイルから読み込んでおきます
CvMat *distortion;		//ゆがみ係数をファイルからロードして入れておきます


MarkerRectangle markers[MAX_RECTCOUNT];//=(MarkerRectangle)malloc(sizeof(MarkerRectangle));






void renderModel()
{


	
	glBegin (GL_LINES);
	GLfloat axisSize=100;
	glLineWidth(2);
	glColor3f (1,0,0); // X axis is red.
	glVertex3f(0,0,0);
	glVertex3f(axisSize,0,0);
	
	glColor3f (0,1,0); // Y axis is green.
	glVertex3f(0,0,0);
	glVertex3f(0,-1*axisSize,0);
	
	glColor3f (0,0,1); // z axis is blue.
	glVertex3f(0,0,0);
	glVertex3f(0,0,axisSize);
	
	glEnd();			

	//---------- モデル描画 -----------------//
	glTranslatef(0,-1*1.5*axisSize,0);
	glmDraw(Model, GLM_SMOOTH | GLM_COLOR);
	
	
}



//Webカメラの内部定数を使って、OpenGLのカメラ行列を設定する
//intrinsic   Webカメラの内部定数。3x3の行列。
//ImageWidth  OpenCVでキャプチャした画像の横幅。画面に表示する幅ではありません。
//ImageHeight  OpenCVでキャプチャした画像の高さ。
//NearClipZ   OpenGLのクリッピング深さの手前の方
//FarClipZ    OpenGLのクリッピング深さの奥の方
int initOpenGLProjectionMatrix(CvMat* intrinsic,const double ImageWidth, const double ImageHeight,double NearClipZ,double FarClipZ)
{
	//軽くチェック
	if( intrinsic->rows != 3 || intrinsic->cols != 3 || CV_MAT_CN(intrinsic->type) != 1 )
    {
    	fprintf(stderr,"intrinsic must be 3x3, single-channel floating point matrix. @initOpenGLProjectionMatrix\n");
    	return -1;
    }
	
	if( ImageWidth<=0 || ImageHeight<=0)
    {
    	fprintf(stderr,"Image width and height must >0. width= %d, height=%d \n",ImageWidth,ImageHeight);
    	return -1;
    }
	
	if( NearClipZ<=0 || FarClipZ<=0)
    {
    	fprintf(stderr,"Clip depth  must >0. width= %g, height=%g \n",NearClipZ,FarClipZ);
    	return -1;
    }

	//Original:
	//From Homography to OpenGL Modelview Matrix
	//http://urbanar.blogspot.com/2011/04/from-homography-to-opengl-modelview.html
	
	// Camera parameters
	double f_x = cvmGet(intrinsic,0,0); // Focal length in x axis
	double f_y = cvmGet(intrinsic,1,1); // Focal length in y axis 
	double c_x = cvmGet(intrinsic,0,2);
	double c_y = cvmGet(intrinsic,1,2);
	
	double fovY = 1/(f_y/ImageHeight*2);
	double aspectRatio = ImageWidth/ImageHeight * f_x/f_y;
  
    double frustum_height = NearClipZ * fovY;
    double frustum_width = frustum_height * aspectRatio;
    double offset_x = (ImageWidth/2 - c_x)/ImageWidth * frustum_width * 2;
    double offset_y = (ImageHeight/2 - c_y)/ImageHeight * frustum_height * 2;
	
	int prev_mode;
	
	fprintf(stdout,"fx:%g fy:%g cx:%g cy:%g Width:%g Height:%g\n",f_x,f_y,c_x,c_y,ImageWidth,ImageHeight);
	fprintf(stdout,"frust_W:%g frust_H:%g OffsetX:%g OffsetY:%g\n",frustum_width,frustum_height,offset_x,offset_y);
	
	
	glGetIntegerv(GL_MATRIX_MODE,&prev_mode);
	

	glMatrixMode (GL_PROJECTION);    /* prepare for and then */ 
    glLoadIdentity ();              

    // Build and apply the projection matrix
    glFrustum(-frustum_width - offset_x, frustum_width - offset_x, -frustum_height - offset_y, frustum_height - offset_y, NearClipZ,FarClipZ);
	
		
	//MatrixModeを復元する
	glMatrixMode(prev_mode);
	return 0;
}
	




//再描画時に呼ばれる関数
//CallBack function for redraw
void OnDisplay(void)
{
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	capFrame=cvQueryFrame(cap);
	
	int result;
	//result=EstimateRotation_TranlationVector(capFrame,intrinsic,distortion,translation_vector,rotation_vector);	

	cvFlip(capFrame,img,0);
	//glRasterPos3f(-1*c_x,-1*(screen_height-c_y),-1*f_x);
	glLoadIdentity();

	//OpenCVの画像を貼付ける地点を指定して、はりつける
	glRasterPos3f(-314.27,-242,-568); //- Cx, -1*(ImageHeight-Cy), -1* Focal Length ぐらいで正しくうつる所
	glDrawPixels(img->width,img->height,GL_BGR, GL_UNSIGNED_BYTE,img->imageData);
	
	
	/*バッファにOpenCVの画像がコピーされたので、
	残りのOpenGL部分を描画します。
	glClear(GL_COLOR_BUFFER_BIT)を実行してしまうと、コピーしたのが消えるので注意。
	*/
	glColor3f(1.0, 1.0, 1.0);
	glMatrixMode (GL_MODELVIEW);
	glColor3f(0,1.0,0);
	glLineWidth(3);
	glLoadIdentity();

	double radians = cvNorm(rotation_vector, NULL, CV_L2,NULL); 
	double degrees = radians*180/3.14; 
/*
	float translate_x=cvmGet(translation_vector,0,0);
	float translate_y=-1*cvmGet(translation_vector,0,1);
	float translate_z=-1*cvmGet(translation_vector,0,2);

	glTranslatef(translate_x,translate_y,translate_z);

	float rotate_x=cvmGet(rotation_vector,0,0);
	float rotate_y=cvmGet(rotation_vector,0,1);
	float rotate_z=cvmGet(rotation_vector,0,2);
	glRotatef(degrees,rotate_x,	-1*rotate_y,	-1*rotate_z);
*/


	//マーカー検出処理
	//最初にデコードする。どちらを向いているかがわかる。
	//その次に頂点を整列する
	//そのあと移動ベクトルと回転ベクトルを求める。
	int foundRectCount=FindRectangle(capFrame,markers,MAX_RECTCOUNT);
	if(foundRectCount>0)
	{


		DecodeMarker2DCode(capFrame,markers,foundRectCount);
		AlignMarkerCorners(markers,foundRectCount);
		EstimateMarkerRotation_TranlationVector(intrinsic,distortion,markers,foundRectCount);
		int printindex=0;

			for(printindex=0;printindex<foundRectCount;printindex++)
		{
		//	printRect(markers[printindex]);
			
			
			glPushMatrix();
			glLoadIdentity();
			
			float rx=0;float ry=0;float rz=0;
			float tx=0;float ty=0;float tz=0;
			
			tx=		markers[printindex].translation_vector.x;
			ty=	-1*	markers[printindex].translation_vector.y;
			tz=	-1*	markers[printindex].translation_vector.z;
			
			rx=		markers[printindex].rotation_vector.x;
			ry=	-1*	markers[printindex].rotation_vector.y;
			rz=	-1*	markers[printindex].rotation_vector.z;
			
			radians = sqrt(rx*rx+ry*ry+rz*rz);
			degrees = radians*180/3.14;
			glTranslatef(tx,ty,tz);
			glRotatef(degrees,rx,ry,rz);
			renderModel();
			glPopMatrix();
		}
		
	
		//座標計算して軸を出してみる
		drawAxis(capFrame,intrinsic,distortion,markers,foundRectCount);
	
	}




	glFlush();
}

//ウィンドウの大きさが変更されたときに呼ばれる関数
//w ウィンドウの横幅
//h ウィンドウの縦幅
//Callback function for resize window
void OnResize(int w, int h)
{
	
	//ウィンドウサイズが変わっても、ビューポートサイズは変更しない。
	//(画面上はつねに640x480の大きさでOpenCVの画像が描画される)
	glMatrixMode (GL_MODELVIEW);  /* back to modelview matrix */
	glViewport(0, 0, WINDOW_WIDTH,WINDOW_HEIGHT);
	glLoadIdentity();
	
	glClear(GL_COLOR_BUFFER_BIT);
	
}

//キーボードが押されたときの処理
//Callback function for keyboard pressed
void OnKeyboard(unsigned char key, int x, int y)
{
	//エスケープキーとかだったらアプリ終了
	switch (key)
	{
		case 'q':
		case 'Q':
		case '\033':  /*ESC Key*/
			exit(0);
  	default:
		break;
	}
}



//
//OpenCVの初期化処理
void initOpenCV()
{
	img=cvLoadImage("00.jpg",1);
	if(NULL==img)
	{
		fprintf(stderr,"Could not load image.\n");
		exit(-1);

	}
	testimg=cvLoadImage("00.jpg",1);
	if(NULL==img)
	{
		fprintf(stderr,"Could not load image.\n");
		exit(-1);

	}
	
	//cap=cvCreateCameraCapture(0);
	cap=cvCaptureFromCAM(1);
	if(NULL==cap)
	{
		cap=cvCaptureFromCAM(0);
		if(NULL==cap)
		{
			fprintf(stderr,"Could not initialize camera.\n");
			exit(-1);
		}
	}
	
	
	
	cvSetCaptureProperty (cap, CV_CAP_PROP_FRAME_WIDTH, IMAGE_WIDTH);
	cvSetCaptureProperty (cap, CV_CAP_PROP_FRAME_HEIGHT, IMAGE_HEIGHT);

}

//OpenCVの片付け処理
void cleanUpOpenCV()
{
	if(NULL!=cap)
	{
		cvReleaseCapture(&cap);
		cap==NULL;

	}
}

void initCVMat()
{
	rotation_vector = cvCreateMat (1, 3, CV_32FC1);
	translation_vector		= cvCreateMat (1, 3, CV_32FC1);

	intrinsic		= cvCreateMat (3, 3, CV_32FC1);
	distortion		= cvCreateMat (1, 4, CV_32FC1);

	//XMLファイルから読み込み
	CvFileStorage *fs;
	fs = cvOpenFileStorage ("camera.xml", 0, CV_STORAGE_READ);
	if(NULL==fs)
	{
		fprintf(stderr,"Could not camera param file!!¥n");
		
	}
	CvFileNode *param;

	fs = cvOpenFileStorage ("camera.xml", 0, CV_STORAGE_READ);
	param = cvGetFileNodeByName (fs, NULL, "intrinsic");
	intrinsic = (CvMat *) cvRead (fs, param,NULL);
	param = cvGetFileNodeByName (fs, NULL, "distortion");
	distortion = (CvMat *) cvRead (fs, param,NULL);
	cvReleaseFileStorage (&fs);
	cvReleaseFileStorage (&fs);
}



void OnTimer(int arg)
{
	glutPostRedisplay();
	glutTimerFunc(TIMER_INTERVAL,OnTimer,1);
}

int main(int argc, char *argv[])
{
	int res=0;
	//OpenCVの初期化処理。画像の読み込みとかカメラとの接続とか
	initOpenCV();
	
	//Webカメラの内部定数ファイル読み込みと、OpenCVで使う配列の初期化
	initCVMat();
	
	
	//ウィンドウサイズと位置の初期化
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(WINDOW_WIDTH,WINDOW_HEIGHT);
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH|GLUT_RGBA);//|GLUT_DOUBLE);	//RGBモードに設定
	glutCreateWindow(argv[0]);

	//コールバック関数一覧を登録してく
	glutDisplayFunc(OnDisplay);		//再描画処理
	glutReshapeFunc(OnResize);		//リサイズ処理
	glutKeyboardFunc(OnKeyboard);	//キーボード処理
	glutTimerFunc(500,OnTimer,1);
	
	
	//Webカメラの内部定数を使って、OpenGLのカメラ行列を設定する
	res=initOpenGLProjectionMatrix(intrinsic,IMAGE_WIDTH,IMAGE_HEIGHT,1,1000);

	
	glClearColor(0.0, 0.0, 0.0, 1.0);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHTING);
	//glEnable(GL_CULL_FACE);
	//glCullFace(GL_BACK);	
	//--------- モデル読み込み ----------//
	Model = glmReadOBJ(modelname);//モデルを読み込む
	glmFacetNormals(Model);//面の法線データを計算
	glmVertexNormals(Model, 90);//頂点の法線を計算、スムージング角は９０度
	glmUnitize(Model);//単位化
	glmScale(Model,100);

	glutMainLoop();
	
	//後片付け
	cleanUpOpenCV();

	//---------- 終了処理 ------------------//
	glmDelete(Model);//不要になったら破棄する

	return 0;
}





