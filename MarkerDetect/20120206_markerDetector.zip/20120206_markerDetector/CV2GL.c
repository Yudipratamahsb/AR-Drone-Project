/****************************************
*	CV2GL.c
*	//OpenCVの画像などを、OpenGLに表示させる関数
*	2012-01 lhaplus8888
*
*****************************************/


#include <stdio.h>
#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <opencv/cxcore.h>

#include "CV2GL.h"

//IplImageを描画します
//画像を既に上下反転しているのであれば、直接ImageProjectionを使ってください。。
void DrawIplImageToGLFrameBuffer(IplImage* srcImage,GLfloat xStart,GLfloat yStart,GLfloat zNear,GLfloat drawZlocation)
{
	//OpenGLのピクセルバッファーをいじるときは、
	//glWriteBuffer関数を使います。
	//OpenCVの画像は左上が(0,0)ですが,
	//OpenGLは左下が(0,0) なので、OpenCV側の画像を上下反転させる必要があります。
	int checkRes=0;
	checkRes=CheckImage(srcImage);
	if(checkRes>0)
	{
		fprintf(stderr,"ImageCheckFaild.@DrawIplImageToGLFrameBuffer\n");
		fprintf(stderr,"Error Code:%d\n",checkRes);
	}

	IplImage* yInvImage=cvCloneImage(srcImage);
	cvFlip(srcImage,yInvImage,0);	//x軸周りに反転
	
	ImageProjection(yInvImage,xStart,yStart,zNear,drawZlocation);
	//後片付け
	cvReleaseImage(&yInvImage);
}


//OpenGLに、上下反転された画像を書いていきます。
void ImageProjection(IplImage* yInvImage,GLfloat xStart,GLfloat yStart,GLfloat zNear,GLfloat drawZlocation)
{
	//チェック
	//３チャネル,Ipl_depth_8u,Not null
	int checkRes=0;
	checkRes=CheckImage(yInvImage);
	if(checkRes>0)
	{
		fprintf(stderr,"image check faild.\n");
		fprintf(stderr,"Error no:%d\n",checkRes);

	}

	if(yInvImage->widthStep!=yInvImage->width*3)
	{
		fprintf(stderr,"WidthStep is missmatch..\n WidthStep%d \n Width:%d\tChannel:%d",
			yInvImage->widthStep,yInvImage->width,yInvImage->nChannels);
	}
	glPushMatrix();
	glLoadIdentity();

	//Zが0だったらスケーリング関係なしで描画。
	if(0==drawZlocation)
	{
	   	glPixelZoom(1,1);
		glRasterPos2i(xStart ,yStart);
	}
	else
	{
		GLfloat scaleFactor=drawZlocation;
		if(scaleFactor<0) scaleFactor=-1*scaleFactor;
		
		scaleFactor=scaleFactor/zNear;
		if(scaleFactor==0)scaleFactor=1;
		//glPixelZoom(scaleFactor,scaleFactor);
		glPixelZoom(1	,1);
		fprintf(stderr,"z:%f x:%f y:%f\n",drawZlocation,320*drawZlocation,240*drawZlocation);
		glRasterPos3f(320*drawZlocation,240*drawZlocation,drawZlocation);
	}
	glDrawPixels(yInvImage->width,yInvImage->height,
				GL_BGR, GL_UNSIGNED_BYTE,
				yInvImage->imageData);
	
	glPopMatrix();
	
}

//画像のチャネル数、ビット深度などのチェック
int CheckImage(IplImage *srcImage)
{
	
	if(NULL==srcImage)
	{
		fprintf(stderr,"SrcImage is null.\n");
		return -1;
	}

	//画像のフォーマットがIPL_DEPTH_8U,3チャネルじゃないと拒否する
	if(srcImage->nChannels!=3)
	{
		fprintf(stderr,"Channel count must 3.\n");
		fprintf(stderr,"img channel is %d\n",(int)srcImage->nChannels);
		return -2;
	}

	if(srcImage->depth!=IPL_DEPTH_8U)
	{
		fprintf(stderr,"Image depth must IPL_DEPTH_8U.\n");
		fprintf(stderr,"img depth is %d\n",(int) srcImage->depth);
		return -3;
	}
	return 0;
}
