//////////////////////////////////////
//
//OpenCVで遊ぼう！
//http://playwithopencv.blogspot.com/
//
//markerdetector2.cpp
//purpose:	Find square marker and decode marker's value
//

#include <stdio.h>
#include <math.h>
#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <opencv/cxcore.h>

#include "rectFinder.h"

#define MARKER_SIZE_MM (70)	//マーカー外枠の大きさ。

#define MAX_RECTCOUNT (20)

CvFont dfont;
CvFont axisfont;


int main(int argc, char * argv[])
{

	CvMat *intrinsic;
	CvMat *distortion;
	
	
	intrinsic		= cvCreateMat (3, 3, CV_32FC1);
	distortion		= cvCreateMat (1, 4, CV_32FC1);

	//XMLファイルから読み込み
	CvFileStorage *fs;
	fs = cvOpenFileStorage ("camera.xml", 0, CV_STORAGE_READ);
	if(NULL==fs)
	{
		fprintf(stderr,"Could not camera param file!!¥n");
	}
	CvFileNode *param;

	fs = cvOpenFileStorage ("camera.xml", 0, CV_STORAGE_READ);
	param = cvGetFileNodeByName (fs, NULL, "intrinsic");
	intrinsic = (CvMat *) cvRead (fs, param,NULL);
	param = cvGetFileNodeByName (fs, NULL, "distortion");
	distortion = (CvMat *) cvRead (fs, param,NULL);
	cvReleaseFileStorage (&fs);

	if(NULL==intrinsic)
	{
		fprintf(stderr,"Could not load intrinsic.xml\n");
		return -1;
	}
	
	if(NULL==distortion)
	{
		fprintf(stderr,"Could not load distortion.xml\n");
		return -1;
	}
	
	int i;

	CvMat object_points;
	CvMat image_points;

	//回転ベクトルと移動ベクトル格納用
	//For store Rotation vector and translation vector
	CvMat *rotation = cvCreateMat (1, 3, CV_32FC1);
	CvMat *translation = cvCreateMat (1 , 3, CV_32FC1);
	

	MarkerRectangle markers[MAX_RECTCOUNT];//=(MarkerRectangle)malloc(sizeof(MarkerRectangle));
	
	
	//マーカーの外枠
	CvPoint3D32f baseMarkerPoints[4];

	baseMarkerPoints[0].x =(float) 0 * MARKER_SIZE_MM;
	baseMarkerPoints[0].y =(float) 0 * MARKER_SIZE_MM;
	baseMarkerPoints[0].z = 0.0;
	baseMarkerPoints[1].x =(float) 1 * MARKER_SIZE_MM;
	baseMarkerPoints[1].y =(float) 0 * MARKER_SIZE_MM;
	baseMarkerPoints[1].z = 0.0;
	baseMarkerPoints[2].x =(float) 1 * MARKER_SIZE_MM;
	baseMarkerPoints[2].y =(float) 1 * MARKER_SIZE_MM;
	baseMarkerPoints[2].z = 0.0;
	baseMarkerPoints[3].x =(float) 0 * MARKER_SIZE_MM;
	baseMarkerPoints[3].y =(float) 1 * MARKER_SIZE_MM;
	baseMarkerPoints[3].z = 0.0;

	IplImage* image;
	IplImage* gsImage;
	IplImage* gsImageContour;

	
	CvCapture *capture = cvCaptureFromCAM(0);
	cvSetCaptureProperty (capture, CV_CAP_PROP_FRAME_WIDTH, 640);
	cvSetCaptureProperty (capture, CV_CAP_PROP_FRAME_HEIGHT, 480);
	
	IplImage * capimg=cvQueryFrame(capture);
		
//	capimg=cvQueryFrame(capture);

	double	process_time;
	image=cvCreateImage(cvGetSize(capimg),IPL_DEPTH_8U,3);
	cvCopy(capimg,image,NULL);
	
	gsImage=cvCreateImage(cvGetSize(image),IPL_DEPTH_8U,1);
	gsImageContour=cvCreateImage(cvGetSize(image),IPL_DEPTH_8U,1);
	char presskey;
	
	//フォントの準備
	//font setting
	

    float hscale      = 0.5f;
    float vscale      = 0.5f;
    float italicscale = 0.0f;
    int  thickness    = 1;
    char text[255] = "";
    cvInitFont (&dfont, CV_FONT_HERSHEY_SIMPLEX , hscale, vscale, italicscale, thickness, CV_AA);


    float axhscale      = 0.8f;
    float axvscale      = 0.8f;
    cvInitFont (&axisfont, CV_FONT_HERSHEY_SIMPLEX , axhscale, axvscale, italicscale, thickness, CV_AA);
	
	

	int contourCount;
	
	//create image for inside image of marker.
	IplImage *marker_inside=cvCreateImage(cvSize(70,70),IPL_DEPTH_8U,1);		
	IplImage *marker_inside_zoom=cvCreateImage(cvSize(marker_inside->width*2,marker_inside->height*2),IPL_DEPTH_8U,1);
	IplImage *tmp_img=cvCloneImage(marker_inside);
		
	CvMat *map_matrix;
	CvPoint2D32f src_pnt[4], dst_pnt[4], tmp_pnt[4];

	map_matrix = cvCreateMat (3, 3, CV_32FC1);
	
	cvNamedWindow ("marker_inside", CV_WINDOW_AUTOSIZE);
	cvNamedWindow ("capture_image", CV_WINDOW_AUTOSIZE);

	process_time = (double)cvGetTickCount();
	//capimg=cvQueryFrame(capture);
	
	char filename[25];
	char msg[200];
	int foundRectCount=0;

	while(1)
	{
		process_time= (double)cvGetTickCount();
		
		capimg=cvQueryFrame(capture);
		
		//sprintf(filename,"TestImg/%02d.jpg",i);
		//capimg=cvLoadImage(filename,1);
		/*if(NULL==capimg)
		{
			fprintf(stderr,"%s could not found.\n",filename);
			continue;
		}
		
		else
		{
		fprintf(stdout,"%s load.\n",filename);
		*/	
		
		
		foundRectCount=FindRectangle(capimg,markers,MAX_RECTCOUNT);
		
		if(0>=foundRectCount)
		{
			sprintf(msg,"No marker");
			
			cvPutText(capimg, msg,cvPoint(550,450),&dfont,CV_RGB(255,0,0));
		}
		else
		{
			//最初にデコードする。どちらを向いているかがわかる。
			//その次に頂点を整列する
			//そのあと移動ベクトルと回転ベクトルを求める。
			
			DecodeMarker2DCode(capimg,markers,foundRectCount);
			AlignMarkerCorners(markers,foundRectCount);
			EstimateMarkerRotation_TranlationVector(intrinsic,distortion,markers,foundRectCount);
			int printindex=0;
		
			/*	for(printindex=0;printindex<foundRectCount;printindex++)
			{
				printRect(markers[printindex]);
			}
			*/
			
			
			//座標計算して軸を出してみる
			drawAxis(capimg,intrinsic,distortion,markers,foundRectCount);
		}
		
	
		process_time = (double)cvGetTickCount()-process_time;
		sprintf(msg,"process_time %gms  marker count:%d", process_time/(cvGetTickFrequency()*1000.),foundRectCount); 
		cvPutText(capimg, msg,cvPoint(2,452),&dfont,CV_RGB(0,0,0));
		cvPutText(capimg, msg,cvPoint(0,450),&dfont,CV_RGB(0,255,0));
		
		
		cvShowImage("RESULT",capimg);
		cvWaitKey(1000);
			
		
	}

return 0;

}


