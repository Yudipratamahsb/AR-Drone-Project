/*
 * estimateRotTransVector.h
 *
 *  Created on: 2012/01/24
 *      Author: yatoukouji
 */
#include <stdio.h>
#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <opencv/cxcore.h>

#define IMAGE_NUM	(1)				 /* 画像数 */
#define PAT_ROW		(10)					/* パターンの行数 */
#define PAT_COL		(7)				 /* パターンの列数 */
#define PAT_SIZE	 (PAT_ROW*PAT_COL)
#define ALL_POINTS (IMAGE_NUM*PAT_SIZE)
#define CHESS_SIZE (20)			 /* パターン1マスの1辺サイズ[mm] */


//画像からチェスボードを探し、チェスボードのTranslationVectortとRotation_vectorを求めます。
//エラーあり：−１
//エラーなし：0
int EstimateRotation_TranlationVector(IplImage* img,
										const CvMat* camera_matrix,
										const CvMat* distortion_coeffs,
										CvMat* translation_vector,
										CvMat* rotation_vector);
