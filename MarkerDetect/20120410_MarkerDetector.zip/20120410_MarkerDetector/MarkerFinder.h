/*
*  rectFinder.h
*  
*
*  Created by lhaplus8888 on 2012/01/29.
*  四角形を探すクラス。
*/

#include <stdio.h>
#include <math.h>
#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <opencv/cxcore.h>


#define GOOD_RECTANGLE (0)
#define GOOD_COLORIMAGE (0)

#define VECTOR_CALCRATED (0)

typedef struct _MarkerRectangle
{
	int MarkerID;//マーカーの番号　　identifier
	CvPoint2D32f outer_corners[4];//コーナーの座標
	double outer_degrees[4];	//コーナーの角度

	CvPoint2D32f inner_corners[4];
	double inner_degrees[4];

	CvPoint3D32f rotation_vector;	//移動ベクトル
	CvPoint3D32f translation_vector;	//回転ベクトル
	int Direction;


} MarkerRectangle;

//カラー画像のチェック。チャネル数、深度など
int CheckColorImage(IplImage* colorImg);


//３点でなす角度を計算します。
double dotDegree(CvPoint common,CvPoint a,CvPoint b);


//四角形かどうかをチェックします。
//チェック方法：内積をとって,60度0120度の間にいるかをチェック
//return 0:四角形と認定(good rectangle)　　-1:四角形ではない(not rectangle)
//正しい四角だったら、MarkerRectangleの情報を更新します。
int CheckRectangle(CvSeq* contour,CvSeq* inner_contour, MarkerRectangle* rectangle);

//--------------------------------------------------------------------------
//四角形を探します。
//	colorImg: 元画像
//	rectangles:結果格納先
//  rectlimitCount:最大検出数
//	戻り値： 見つけた四角形の数。
//--------------------------------------------------------------------------
int FindRectangle(IplImage* colorImg,MarkerRectangle* rectangles,const int rectLimitCount);

//マーカーの頂点を並び替えます。
void AlignMarkerCorners(MarkerRectangle* rectangles,const int rectCount);



//マーカーの移動ベクトルと回転ベクトルを求めます。
void EstimateMarkerRotation_TranlationVector(const CvMat* camera_matrix,
	const CvMat* distortion_coeffs,
	MarkerRectangle* rectangle,
	const int rectCount);


//座標軸を書きます。
void drawAxis(IplImage* colorImg,
	const CvMat* camera_matrix,
	const CvMat* distortion_coeffs,
	MarkerRectangle* rectangle,
	const int rectCount);

//--------------------------------------------------------------------------
//マーカーをデコードして、番号を割りふります。
//この関数を使う前に、FindRectangleを使ってマーカーの頂点情報と角度情報を計算しておいてください。
//	colorImg: 元画像
//	rectangles:頂点／角度が既に求まっているMarkerRectangleの配列。
//  rectCount:検査個数
//	戻り値： 見つけた四角形の数。
//--------------------------------------------------------------------------
void DecodeMarker2DCode(IplImage* colorImg, MarkerRectangle* rectangles,const int rectCount);

int CheckDirection(IplImage* projectedImg);
