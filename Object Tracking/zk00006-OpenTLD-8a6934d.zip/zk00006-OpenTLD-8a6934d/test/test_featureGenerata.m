clc;

trM = 3;
trN = 3;
trDepth = 15;
f = tldFeatureGenerate(trM,trN,trDepth)


    
    
